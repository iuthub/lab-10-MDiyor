function computeBMI(weight, height){
	var BMI = 703*weight/(height*height);
	return BMI;
}