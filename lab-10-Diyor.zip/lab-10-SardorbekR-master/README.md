# Lab 10

In this lab, you have to finish at least 4 JavaScript exercises given in corresponding pdf file. 


## Student Details

- Student ID: U1610207	
- Student Name: Sardorbek
- Section Number: 002